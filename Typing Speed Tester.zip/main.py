import tkinter as tk
from gui import TypingSpeedGUI

if __name__ == "__main__":
    root = tk.Tk()
    app = TypingSpeedGUI(root)
    root.mainloop()
