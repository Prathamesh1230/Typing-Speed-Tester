sentences = [
    "The quick brown fox jumps over the lazy dog.",
    "Python is an amazing programming language.",
    "Typing speed improves with practice and patience.",
    "Artificial intelligence is shaping our future.",
    "Alex J is building awesome Python projects!"
]
